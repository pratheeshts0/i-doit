<?php
namespace idoit\Exception;

/**
 * Out Of Memory Exception
 *
 * @package     i-doit
 * @subpackage  Core
 * @author      Dennis Stücken <dstuecken@synetics.de>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
class OutOfMemoryException extends \Exception
{

}