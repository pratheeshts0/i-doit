alert(	'Ein oder mehrere wichtige Javascript Funktionen konnten nicht initialisiert werden, ' +
		'weil Ihr Browser einige veraltete i-doit Scripts noch im Zwischenspeicher hält.\n' +
		'Bitte leeren Sie ihren Browser Cache und dessen temporäre Dateien, damit die i-doit ' +
		'Oberfläche wieder einwandfrei geladen werden kann.\n\n' + 
		'Dieses Problem kann in einigen modernen Browsern nach einem i-doit Update bzw. ' +
		'einer Neu-Installationen auftreten.\n\n'+
		'Konsultieren Sie http://www.i-doit.org/forum für weitere Informationen über dieses Verhalten.');