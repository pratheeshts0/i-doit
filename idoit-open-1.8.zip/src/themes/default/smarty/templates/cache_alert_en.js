alert(	'One or more javascript functions are not correctly initialized, '+
		'because your web-browser has cached some outdated i-doit scripts.\n' + 
		'You need to clear your browser cache and it\'s temporary files in order ' +
		'to work with i-doit properly.\n\n'+
		'This problem can occur in some modern browsers after an i-doit update ' +
		'or re-installation.\n\n'+
		'Consult http://www.i-doit.org/forum for advanced information about this behaviour.');