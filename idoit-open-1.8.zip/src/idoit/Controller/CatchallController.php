<?php
namespace idoit\Controller;

use idoit\Component\ContainerFacade;
use idoit\Component\Provider\DiFactory;
use idoit\Component\Provider\DiInjectable;

/**
 * i-doit Base Controller
 *
 * @package     i-doit
 * @subpackage  Core
 * @author      Dennis Stücken <dstuecken@synetics.de>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 */
final class CatchallController extends Base
{
    use DiInjectable;

    /**
     * Factory with $container parameter
     *
     * @param ContainerFacade $container
     *
     * @return CatchallController
     */
    public static function factory(ContainerFacade $container)
    {
        $instance = new CatchallController();
        $instance->setDi($container);

        return $instance;
    }

    /**
     * Main Request handler
     *
     * @param \isys_register $p_request
     *
     * @throws \Exception
     */
    final public function handle(\isys_register $p_request)
    {
        global $g_modman;

        /**
         * @todo remove this legacyRequest in future
         */
        $this->getDi()->legacyRequest = $p_request;

        if (isset($p_request->module))
        {
            /**
             * Get module instance
             */
            if (($l_module_id = $g_modman->is_installed($p_request->module)))
            {

                /**
                 * Load and start the module
                 */
                $this->getDi()->application->module = $g_modman->load($l_module_id, $p_request);

                /**
                 * Preformat action to match class naming conventions
                 */
                $p_request->action = str_replace(' ', '', ucwords(str_replace('-', ' ', $p_request->action)));

                /**
                 * @var $l_controller \isys_controller
                 */
                if (isset($p_request->action) && $p_request->action !== '')
                {
                    $l_class = 'idoit\\Module\\' . str_replace(' ', '', ucfirst(str_replace('_', ' ', $p_request->module))) . '\\Controller\\' . $p_request->action;
                    if (class_exists($l_class))
                    {
                        $l_controller = new $l_class($this->getDi()->application->module);
                    }
                }
                else
                {
                    $l_class = 'idoit\\Module\\' . str_replace(' ', '', ucfirst(str_replace('_', ' ', $p_request->module))) . '\\Controller\\Main';
                    if (class_exists($l_class))
                    {
                        $l_controller = new $l_class($this->getDi()->application->module);
                    }
                }

                /**
                 * Redirect to new controller
                 */
                if (isset($l_controller))
                {
                    // Call controller's pre route function
                    if (method_exists($l_controller, 'pre'))
                    {
                        $l_controller->pre($p_request, $this);
                    }

                    if (isset($p_request->method) && $p_request->method !== '' && method_exists($l_controller, $p_request->method))
                    {
                        // Call controller's handler
                        $l_view = call_user_func(
                            [
                                $l_controller,
                                $p_request->method
                            ],
                            $p_request,
                            $this
                        );
                    }
                    else
                    {
                        // Call controller's main handler
                        $l_view = $l_controller->handle(
                            $p_request,
                            $this->getDi()->application
                        );
                    }

                    // If controller is a NavbarHandable, also call onNew, onSave etc. events
                    if (is_a($l_controller, 'idoit\Controller\NavbarHandable'))
                    {
                        $dispatcher = \idoit\Dispatcher\NavbarDispatcher::factory($this->getDi());

                        $l_view = $dispatcher->dispatch(
                            $l_controller,
                            $p_request->get('POST')
                                ->get(C__GET__NAVMODE)
                        );
                    }

                    /**
                     * Process main tree
                     */
                    \idoit\Tree\TreeProcessor::factory($this->getDi())
                        ->process($l_controller, $p_request);

                    // Call controller's post route funciton
                    if (method_exists($l_controller, 'post'))
                    {
                        $l_controller->post($p_request, $this);
                    }

                    /**
                     * Process and Render the view, if view is renderable
                     */
                    if ($l_view && is_a($l_view, 'idoit\View\Renderable', true))
                    {
                        $l_view->process(
                            $this->getDi()->application->module,
                            $this->getDi()->template,
                            $l_controller->dao($this->getDi()->application)
                        );

                        /* auto assign data
                        isys_component_template::instance()->assign(
                            'data', $l_view->getData()
                        );
                        */

                        $l_view->render();
                    }
                }
                /**
                 * Load module via old deprecated way
                 *
                 * @deprecated
                 */
                else
                {
                    if (($l_mod_id = $g_modman->is_installed($p_request->module)))
                    {
                        // Boot load the module in it's legacy way
                        //
                    }
                    else
                    {
                        // Call 404 handler
                        $this->getDi()->application->error404($p_request);
                    }
                }
            }
        }
        else
        {
            throw new \Exception(
                'Request error for request ' . \isys_request_controller::instance()
                    ->path() . ' : ' . var_export($p_request, true)
            );
        }
    } // function
}