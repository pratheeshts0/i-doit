<?php
namespace idoit\Component;

use dstuecken\Notify\Handler\AbstractHandler;
use dstuecken\Notify\NotificationCenter;
use isys_component_database as Database;
use isys_component_signalcollection as SignalCollection;
use isys_component_template as Template;
use Pimple\Container;

/**
 * i-doit Container Facade
 *
 * Gives access to some of the most used container services by identifying them as a @property.
 *
 * @package     idoit\Component
 * @author      Dennis Stücken <dstuecken@i-doit.com>
 * @copyright   synetics GmbH
 * @license     http://www.gnu.org/licenses/agpl-3.0.html GNU AGPLv3
 *
 * @property Logger                  logger
 * @property Database                database_system
 * @property Database                database
 * @property AbstractHandler[]       notifyHandler
 * @property NotificationCenter      notify
 * @property SignalCollection        signals
 * @property Template                template
 * @property \isys_component_session session
 * @property \isys_locale            locales
 * @property \isys_application       application
 *
 */
class ContainerFacade extends Container
{

    /**
     * Checks if a service exists in the container
     *
     * @param string $service
     *
     * @return bool
     */
    public function has($service)
    {
        return isset($this[$service]);
    }

    /**
     * @param $id
     * @param $value
     */
    public function __set($id, $value)
    {
        $this[$id] = $value;
    }

    /**
     * @param $id
     *
     * @return mixed
     */
    public function __get($id)
    {
        return $this[$id];
    }

    /**
     * @param $id
     *
     * @return bool
     */
    public function __isset($id)
    {
        return isset($this[$id]);
    }

    /**
     * @param $id
     */
    public function __unset($id)
    {
        unset($this[$id]);
    }
}