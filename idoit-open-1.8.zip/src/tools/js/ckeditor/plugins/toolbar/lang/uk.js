﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'uk', {
	toolbarCollapse: 'Згорнути панель інструментів',
	toolbarExpand: 'Розгорнути панель інструментів',
	toolbarGroups: {
		document: 'Документ',
		clipboard: 'Буфер обміну / Скасувати',
		editing: 'Редагування',
		forms: 'Форми',
		basicstyles: 'Основний Стиль',
		paragraph: 'Параграф',
		links: 'Посилання',
		insert: 'Вставити',
		styles: 'Стилі',
		colors: 'Кольори',
		tools: 'Інструменти'
	},
	toolbars: 'Панель інструментів редактора'
} );
